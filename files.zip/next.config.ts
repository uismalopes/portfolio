import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  reactStrictMode: true,
  output: 'export',
  images: {
    loader: 'default',
    unoptimized: true,
  },
};

export default nextConfig;
