import BASE_OAS_DELAY from './BASE_OAS_DELAY';

export { BASE_OAS_DELAY };
