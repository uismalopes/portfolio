const BASE_OAS_DELAY = 100;

export default BASE_OAS_DELAY;
