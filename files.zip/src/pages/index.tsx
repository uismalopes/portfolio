import { About, Home, Projects } from '@/components';
import { Roboto, Poppins } from 'next/font/google';
import AOS from 'aos';
import { useEffect } from 'react';
import { useSmoothScroll } from '@/hooks';

const roboto = Roboto({
  variable: '--font-roboto',
  subsets: ['latin'],
});

const poppins = Poppins({
  variable: '--font-poppins',
  weight: ['400', '500', '600', '700'],
  subsets: ['latin'],
});

export default function Layout() {
  const smoothScroll = useSmoothScroll();
  useEffect(() => {
    AOS.init({
      duration: 1000,
    });
    import('smooth-scroll').then((SmoothScroll) => {
      new SmoothScroll.default('a[href*="#"]', {
        speed: 800,
        speedAsDuration: true,
        header: '[data-scroll-header]',
      });

      smoothScroll();
    });
  }, [smoothScroll]);

  return (
    <div className={`${roboto.variable} ${poppins.variable} h-full`}>
      <main>
        <Home />
        <About />
        <Projects />
      </main>
    </div>
  );
}
