import User from '@/assets/images/user.svg';
import Image from 'next/image';

function Avatar() {
  return (
    <div className="flex items-center justify-center bg-[url(/mask.svg)] bg-contain bg-center bg-no-repeat">
      <Image src={User} alt="" priority />
    </div>
  );
}

export default Avatar;
