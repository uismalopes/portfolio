import Image from 'next/image';

function Navbar() {
  return (
    <nav className="fixed z-10 w-full" data-scroll-header>
      <div className="bg-default container rounded-b-2xl">
        <div className="flex w-full items-center justify-between py-3">
          <div>
            <Image src={'/logo.svg'} alt="Logo" width={50} height={50} />
          </div>
          <div>
            <ul className="flex gap-2">
              <li>
                <a href="#home" className="nav-bar-link active">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="nav-bar-link">
                  About
                </a>
              </li>
              <li>
                <a href="#skills" className="nav-bar-link">
                  Skills
                </a>
              </li>
              <li>
                <a href="#projects" className="nav-bar-link">
                  Projects
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
