import dynamic from 'next/dynamic';
import Home from './Home';
import Navbar from './Navbar';
import Projects from './Projects';

const About = dynamic(() => import('./About'), {
  ssr: false,
});

export { Navbar, Home, About, Projects };
