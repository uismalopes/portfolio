import Hmnc from '@/assets/images/hmnc.png';
import Leccor from '@/assets/images/leccor.png';
import Verdegente from '@/assets/images/verdegente.png';
import Plootools from '@/assets/images/plootools.png';
import Image from 'next/image';
import ShowMoreText from 'react-show-more-text';
import { BASE_OAS_DELAY } from '@/constants';

const PROJECTS = {
  sites: [
    {
      link: 'https://hmnc.com.br/',
      name: 'HMNC Engenharia',
      image: Hmnc,
      description:
        'Website desenvolvido com Next.js, focado em desempenho, escalabilidade e experiência do usuário.',
    },
    {
      link: 'https://www.leccor.com.br/',
      name: 'Leccor',
      image: Leccor,
      description:
        'Website desenvolvido com PHP, jQuery, CSS e JavaScript durante minha atuação na Ivoire, com foco em soluções dinâmicas e design responsivo.',
    },
    {
      link: 'http://www.verdegente.com/',
      name: 'Verdegente',
      image: Verdegente,
      description:
        'Website criado com jQuery, CSS e JavaScript enquanto trabalhava na Ivoire, priorizando interatividade e usabilidade.',
    },
  ],
  personal: [
    {
      link: '',
      name: 'React Gen cli',
      image: Plootools,
      description:
        'Biblioteca desenvolvida para apoiar a comunidade de desenvolvimento, permitindo a criação dinâmica de componentes React com base em configurações personalizadas ou padrões do projeto.',
    },
    {
      link: 'https://marketplace.visualstudio.com/items?itemName=UismaLopes.plootools',
      name: 'Plootools',
      image: Plootools,
      description:
        'Extensão desenvolvida durante meu trabalho na Ploomes, com o objetivo de automatizar a criação de componentes em React dentro da arquitetura adotada pela empresa. A ferramenta gera automaticamente a estrutura do componente, arquivos de teste e um boilerplate de estado utilizando RecoilJS, otimizando significativamente o tempo de desenvolvimento.',
    },
  ],
};

function Projects() {
  return (
    <section id="projects" className="page">
      <div className="container">
        <div data-aos="fade-down" className="mb-24">
          <h4 className="title-code">Projects</h4>
          <h2 className="sub-title-pages">
            De ideias pessoais a soluções para o mercado.
          </h2>
        </div>

        <h4 className="title-code mb-10">Projetos Profissionais</h4>
        <div className="grid grid-cols-3 gap-10">
          {PROJECTS.sites.map((item, index) => (
            <div
              key={`project-${item.name}`}
              className="relative"
              data-aos="fade-right"
              data-aos-delay={BASE_OAS_DELAY * index}
            >
              <Image src={item.image} alt="" />
              <div className="bg-default absolute left-2/4 max-h-44 w-3/4 -translate-x-1/2 -translate-y-20 p-5">
                <h5 className="text-primary mb-2">{item.name}</h5>
                <ShowMoreText
                  lines={3}
                  more="Ver mais"
                  less="Ver menos"
                  anchorClass="cursor-pointer text-primary"
                >
                  <p>{item.description}</p>
                </ShowMoreText>
              </div>
            </div>
          ))}
        </div>

        <h4 className="title-code mt-36 mb-10">Projetos Pessoais</h4>
        <div className="grid grid-cols-3 gap-10">
          {PROJECTS.personal.map((item, index) => (
            <div
              key={`project-${item.name}`}
              className="relative"
              data-aos="fade-right"
              data-aos-delay={BASE_OAS_DELAY * index}
            >
              <Image src={item.image} alt="" />
              <div className="bg-default absolute left-2/4 max-h-44 w-3/4 -translate-x-1/2 -translate-y-20 overflow-y-auto p-5">
                <h5 className="text-primary mb-2">{item.name}</h5>
                <ShowMoreText
                  lines={3}
                  more="Ver mais"
                  less="Ver menos"
                  anchorClass="cursor-pointer text-primary"
                >
                  <p>{item.description}</p>
                </ShowMoreText>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
