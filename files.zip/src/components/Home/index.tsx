import { MdArrowDownward } from 'react-icons/md';
import Avatar from '../Avatar';
import { CONTACTS } from './constants';

function Home() {
  return (
    <section
      className="bg-dark page relative flex h-screen items-center"
      id="home"
    >
      <div className="container">
        <div className="grid grid-cols-2 items-center">
          <div data-aos="fade-down">
            <div className="mb-5">
              <h1 className="uppercase">Hi, I&apos;m uisma</h1>
              <h2 className="uppercase">
                <span className="text-primary">Front-end</span> developer
              </h2>
            </div>
            <p className="font-poppins leading-7">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce
              magna quam, vestibulum vitae blandit sit amet, viverra dapibus
              ipsum. In sit amet dui at dui mollis eleifend vitae blandit ex.
            </p>
          </div>
          <div data-aos="fade-right">
            <Avatar />
            <div className="mt-5 flex justify-center gap-7">
              {CONTACTS.map((contact) => (
                <a
                  href={contact.link}
                  target="_blank"
                  key={contact.name}
                  className="text-dark group flex flex-col items-center gap-3"
                >
                  <span className="bg-primary group-hover:bg-primary/50 flex size-10 items-center justify-center rounded-full transition-all">
                    <contact.Icon />
                  </span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
      <a
        href="#about"
        className="absolute bottom-1.5 left-1/2 flex rounded-xl bg-black/25 px-2 py-3"
      >
        <span className="animate-arrow block">
          <MdArrowDownward size={40} />
        </span>
      </a>
    </section>
  );
}

export default Home;
