import { FaLinkedin, FaEnvelope, FaGithub } from 'react-icons/fa';

const CONTACTS = [
  {
    name: 'uisma@outlook.com',
    Icon: FaEnvelope,
    link: 'mailto:uisma@outlook.com',
  },
  {
    name: 'uismalopes',
    Icon: FaLinkedin,
    link: 'https://www.linkedin.com/in/uismalopes',
  },
  {
    name: '@uismalopes',
    Icon: FaGithub,
    link: 'https://github.com/uismalopes',
  },
];

export default CONTACTS;
