import CONTACTS from './CONTACTS';

export { CONTACTS };
