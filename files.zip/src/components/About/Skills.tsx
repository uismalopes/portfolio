import { BASE_OAS_DELAY } from '@/constants';
import { SKILLS } from './constants';
import { generateRandomTransform } from './library';

function Skills() {
  return (
    <div className="flex flex-wrap items-center justify-between gap-14 p-10">
      {SKILLS.map((skill, index) => (
        <div
          key={skill.name}
          data-aos="fade-right"
          data-aos-delay={BASE_OAS_DELAY * index}
        >
          <div
            className="flex flex-col items-center"
            style={generateRandomTransform()}
          >
            <skill.Icon size={60} color={skill.color} />
            <p className="mt-2 text-center text-lg">{skill.name}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Skills;
