import aboutData from '@/data/aboutData.json';
import Card from './Card';
import Skills from './Skills';
import { BASE_OAS_DELAY } from '@/constants';
import Avatar from '../Avatar';

function About() {
  return (
    <section className="page" id="about">
      <div className="container">
        <div className="grid grid-cols-2">
          <div data-aos="fade-left">
            <Avatar />
          </div>
          <div data-aos="fade">
            <h4 className="title-code">About me</h4>
            <h2 className="sub-title-pages">
              Apaixonado por código & inovação
            </h2>

            <p className="leading-7">
              Minha jornada no mundo digital começou em 2015, quando iniciei um
              curso de Web Design. Naquela época, me encantei por manipulação de
              imagens e edição de vídeos, mas foi ao entrar em contato com o
              desenvolvimento front-end que realmente me encontrei. Desde então,
              sigo trilhando esse caminho com paixão e dedicação.
            </p>
            <p className="leading-7">
              Sou uma pessoa curiosa e movida por aprendizado constante. Gosto
              de explorar novas tecnologias, me aventurar em áreas como back-end
              e inteligência artificial, e ampliar meus conhecimentos para
              entregar soluções cada vez mais completas e criativas.
            </p>
          </div>
        </div>

        <div className="mt-32 flex flex-col gap-32">
          <div>
            <div>
              <h4 className="title-code mb-10">Works</h4>
              <div className="grid grid-cols-2 gap-10">
                {aboutData.works.map((item, index) => (
                  <div
                    key={`work-${item.title}-${item.subtitle}`}
                    data-aos="fade-down"
                    data-aos-delay={BASE_OAS_DELAY * index}
                  >
                    <Card item={item} />
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div>
            <h4 className="title-code mb-10">Educations</h4>
            <div className="flex justify-between gap-10">
              {aboutData.educations.map((item, index) => (
                <div
                  key={`work-${item.title}-${item.subtitle}`}
                  data-aos="fade-down"
                  data-aos-delay={BASE_OAS_DELAY * index}
                >
                  <Card item={item} />
                </div>
              ))}
            </div>
          </div>
        </div>
        <section id="skills" className="pt-32">
          <h4 className="title-code">Skills</h4>
          <Skills />
        </section>
      </div>
    </section>
  );
}

export default About;
