import {
  FaJsSquare,
  FaReact,
  FaHtml5,
  FaCss3Alt,
  FaSass,
  FaAngular,
  FaVuejs,
} from 'react-icons/fa';
import { BiLogoTypescript, BiLogoTailwindCss } from 'react-icons/bi';
import { SiWebpack } from 'react-icons/si';
import { RiNextjsFill } from 'react-icons/ri';

const SKILLS = [
  { name: 'JavaScript', Icon: FaJsSquare, color: '#F7DF1E' },
  { name: 'React', Icon: FaReact, color: '#61DAFB' },
  { name: 'TypeScript', Icon: BiLogoTypescript, color: '#3178C6' },
  { name: 'CSS3', Icon: FaCss3Alt, color: '#2965F1' },
  { name: 'HTML5', Icon: FaHtml5, color: '#E34F26' },
  { name: 'Tailwind CSS', Icon: BiLogoTailwindCss, color: '#38BDF8' },
  { name: 'AngularJS', Icon: FaAngular, color: '#E23237' },
  { name: 'Vue.js', Icon: FaVuejs, color: '#42b883' },
  { name: 'Sass', Icon: FaSass, color: '#C69' },
  { name: 'Webpack', Icon: SiWebpack, color: '#8DD6F9' },
  { name: 'NextJs', Icon: RiNextjsFill, color: '#fff' },
];

export default SKILLS;
