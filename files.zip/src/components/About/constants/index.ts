import SKILLS from './SKILLS';

export { SKILLS };
