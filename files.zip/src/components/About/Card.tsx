import { AboutData } from '@/types';
import { useMemo } from 'react';

interface CardItem {
  item: AboutData;
}

function Card(props: CardItem) {
  const { item } = props;
  const classNameActived = useMemo(
    () => (!item.end ? 'bg-primary text-dark' : ''),
    [item.end]
  );
  return (
    <div>
      <span
        className={`border-primary font-poppins mb-4 inline-block border px-5 py-2 ${classNameActived}`}
      >
        {item.start} - {item.end || 'Atual'}
      </span>
      <div className="mb-3 font-bold">
        <p>{item.title}</p>
        <p>{item.subtitle}</p>
      </div>
      {item.description && <p className="text-sm">{item.description}</p>}
    </div>
  );
}

export default Card;
