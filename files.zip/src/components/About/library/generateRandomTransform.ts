import { CSSProperties } from 'react';

function generateRandomTransform(): CSSProperties {
  return {
    transform: `rotate(${Math.random() * 25 - 12.5}deg)`,
    marginTop: `${Math.random() * 20}px`,
    marginBottom: `${Math.random() * 20}px`,
    opacity: 0.7 + Math.random() * 0.3,
    transformOrigin: 'center',
  };
}

export default generateRandomTransform;
