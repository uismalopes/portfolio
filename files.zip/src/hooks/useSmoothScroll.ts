import { debounce } from 'lodash';

function useSmoothScroll() {
  const onScroll = debounce(function (this: Window) {
    const sections = document.querySelectorAll<HTMLElement>('section[id]');
    const nav = this.document.querySelector('nav');

    if (!nav) return;

    const navLinks = nav.querySelectorAll('a[href^="#"]');
    const currentPosition = this.scrollY;

    const navHeight = nav.offsetHeight;

    sections.forEach((section) => {
      const top = section.offsetTop - navHeight;
      const bottom = top + section.offsetHeight;

      if (currentPosition >= top && currentPosition <= bottom) {
        const sectionId = section.getAttribute('id');
        if (!sectionId) return;

        navLinks.forEach((item) => {
          item.classList.remove('active');
          const hasAttr = item.getAttribute('href')?.includes(sectionId);
          if (hasAttr) {
            item.classList.add('active');
          }
        });
      }
    });
  }, 100);

  return () => {
    window.addEventListener('scroll', onScroll);
  };
}

export default useSmoothScroll;
