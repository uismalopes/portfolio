import AboutData from './AboutData';

export type { AboutData };
