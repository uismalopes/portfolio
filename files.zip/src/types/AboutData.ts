type AboutData = {
  start: string;
  end: string;
  title: string;
  subtitle: string;
  description?: string;
};

export default AboutData;
